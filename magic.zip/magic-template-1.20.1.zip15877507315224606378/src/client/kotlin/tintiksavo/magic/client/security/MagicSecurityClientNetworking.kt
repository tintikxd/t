package tintiksavo.magic.client.security

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking
import net.minecraft.core.BlockPos
import tintiksavo.magic.security.MagicSecurityNetworking

object MagicSecurityClientNetworking {
    fun register() {
        ClientPlayNetworking.registerGlobalReceiver(MagicSecurityNetworking.REGIONS_CHANNEL) { client, _, buffer, _ ->
            val admin = buffer.readBoolean()
            val regionCount = buffer.readVarInt()
            val regions = ArrayList<SecurityRegionView>(regionCount)
            repeat(regionCount) { regions += readRegion(buffer) }
            val zoneCount = buffer.readVarInt()
            val zones = ArrayList<SecurityRegionView>(zoneCount)
            repeat(zoneCount) { zones += readRegion(buffer) }

            client.execute {
                MagicSecurityClientState.setRegions(admin, regions, zones)
            }
        }

        ClientPlayNetworking.registerGlobalReceiver(MagicSecurityNetworking.SELECTION_CHANNEL) { client, _, buffer, _ ->
            val admin = buffer.readBoolean()
            val dimension = buffer.readUtf()
            val first = if (buffer.readBoolean()) buffer.readBlockPos() else null
            val second = if (buffer.readBoolean()) buffer.readBlockPos() else null
            client.execute {
                MagicSecurityClientState.setSelection(admin, dimension, first, second)
            }
        }

        ClientPlayConnectionEvents.DISCONNECT.register { _, _ ->
            MagicSecurityClientState.clear()
        }
    }

    private fun readRegion(buffer: net.minecraft.network.FriendlyByteBuf) = SecurityRegionView(
        name = buffer.readUtf(),
        dimension = buffer.readUtf(),
        minX = buffer.readInt(), minY = buffer.readInt(), minZ = buffer.readInt(),
        maxX = buffer.readInt(), maxY = buffer.readInt(), maxZ = buffer.readInt(),
        safetyEnabled = buffer.readBoolean()
    )
}
