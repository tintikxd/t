package tintiksavo.magic.client.security

import net.minecraft.core.BlockPos

/** Read-only geometry synchronized by the server. */
data class SecurityRegionView(
    val name: String,
    val dimension: String,
    val minX: Int,
    val minY: Int,
    val minZ: Int,
    val maxX: Int,
    val maxY: Int,
    val maxZ: Int,
    val safetyEnabled: Boolean
)

object MagicSecurityClientState {
    @Volatile var isAdmin: Boolean = false
        private set
    @Volatile var adminRegions: List<SecurityRegionView> = emptyList()
        private set
    @Volatile var safetyZones: List<SecurityRegionView> = emptyList()
        private set
    @Volatile var selectionDimension: String = ""
        private set
    @Volatile var selectionFirst: BlockPos? = null
        private set
    @Volatile var selectionSecond: BlockPos? = null
        private set

    fun setRegions(
        admin: Boolean,
        regions: List<SecurityRegionView>,
        zones: List<SecurityRegionView>
    ) {
        isAdmin = admin
        adminRegions = if (admin) regions else emptyList()
        safetyZones = zones
        if (!admin) clearSelection()
    }

    fun setSelection(admin: Boolean, dimension: String, first: BlockPos?, second: BlockPos?) {
        if (!admin) {
            clearSelection()
            return
        }
        isAdmin = true
        selectionDimension = dimension
        selectionFirst = first
        selectionSecond = second
    }

    fun clearSelection() {
        selectionDimension = ""
        selectionFirst = null
        selectionSecond = null
    }

    fun clear() {
        isAdmin = false
        adminRegions = emptyList()
        safetyZones = emptyList()
        clearSelection()
    }
}
