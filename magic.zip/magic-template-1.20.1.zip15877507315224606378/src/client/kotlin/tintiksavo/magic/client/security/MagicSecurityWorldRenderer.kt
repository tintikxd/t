package tintiksavo.magic.client.security

import com.mojang.blaze3d.vertex.PoseStack
import com.mojang.blaze3d.vertex.VertexConsumer
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents
import net.minecraft.client.Minecraft
import net.minecraft.client.renderer.LightTexture

import net.minecraft.client.renderer.RenderType
import net.minecraft.client.renderer.texture.OverlayTexture
import net.minecraft.core.BlockPos
import net.minecraft.resources.ResourceLocation
import net.minecraft.world.phys.Vec3
import org.joml.Matrix3f
import org.joml.Matrix4f
import tintiksavo.magic.Magic
import kotlin.math.max
import kotlin.math.min

/** Draws selection/region outlines for admins and the red danger barrier for everyone. */
object MagicSecurityWorldRenderer {
    private val BARRIER_TEXTURE = ResourceLocation(Magic.MOD_ID, "textures/misc/security_barrier.png")

    private data class Bounds(
        val minX: Double, val minY: Double, val minZ: Double,
        val maxX: Double, val maxY: Double, val maxZ: Double
    )

    private data class TexturedVertex(val x: Float, val y: Float, val z: Float, val u: Float, val v: Float)

    fun register() {
        WorldRenderEvents.AFTER_ENTITIES.register(::render)
    }

    private fun render(context: WorldRenderContext) {
        val world = context.world() ?: return
        val minecraft = Minecraft.getInstance()
        val player = minecraft.player ?: return
        val dimension = world.dimension().location().toString()
        val camera = context.camera().position
        val consumers = context.consumers() ?: return
        val poseStack = context.matrixStack() ?: return

        poseStack.pushPose()
        poseStack.translate(-camera.x, -camera.y, -camera.z)
        val pose = poseStack.last()
        val matrix = pose.pose()
        val normal = pose.normal()

        // The red field is public: every player must see an active safety-zone boundary.
        for (zone in MagicSecurityClientState.safetyZones) {
            if (zone.dimension != dimension) continue
            val bounds = bounds(zone.minX, zone.minY, zone.minZ, zone.maxX, zone.maxY, zone.maxZ)
            if (!nearCamera(bounds, camera, 256.0)) continue
            drawBarrier(consumers.getBuffer(RenderType.entityTranslucent(BARRIER_TEXTURE)), matrix, normal, bounds)
            drawOutline(consumers.getBuffer(RenderType.lines()), matrix, normal, bounds, 255, 35, 35, 230)
        }

        if (MagicSecurityClientState.isAdmin) {
            for (region in MagicSecurityClientState.adminRegions) {
                if (region.dimension != dimension) continue
                val bounds = bounds(region.minX, region.minY, region.minZ, region.maxX, region.maxY, region.maxZ)
                if (!nearCamera(bounds, camera, 256.0)) continue
                drawOutline(consumers.getBuffer(RenderType.lines()), matrix, normal, bounds, 255, 190, 55, 230)
            }

            if (MagicSecurityClientState.selectionDimension == dimension) {
                val first = MagicSecurityClientState.selectionFirst
                val second = MagicSecurityClientState.selectionSecond
                if (first != null) {
                    val a = second ?: first
                    val selectionBounds = bounds(
                        min(first.x, a.x), min(first.y, a.y), min(first.z, a.z),
                        max(first.x, a.x), max(first.y, a.y), max(first.z, a.z)
                    )
                    if (nearCamera(selectionBounds, camera, 256.0)) {
                        drawOutline(consumers.getBuffer(RenderType.lines()), matrix, normal, selectionBounds, 60, 220, 255, 255)
                    }
                }
            }
        }

        poseStack.popPose()
    }

    private fun bounds(minX: Int, minY: Int, minZ: Int, maxX: Int, maxY: Int, maxZ: Int) = Bounds(
        minX.toDouble(), minY.toDouble(), minZ.toDouble(),
        maxX + 1.0, maxY + 1.0, maxZ + 1.0
    )

    private fun nearCamera(bounds: Bounds, camera: Vec3, range: Double): Boolean {
        // Measure to the closest point of the cuboid, not its center. This matters for
        // enormous protected areas whose center may be far away while an edge is nearby.
        val dx = maxOf(bounds.minX - camera.x, 0.0, camera.x - bounds.maxX)
        val dy = maxOf(bounds.minY - camera.y, 0.0, camera.y - bounds.maxY)
        val dz = maxOf(bounds.minZ - camera.z, 0.0, camera.z - bounds.maxZ)
        return dx * dx + dy * dy + dz * dz <= range * range
    }

    private fun drawOutline(
        consumer: VertexConsumer,
        matrix: Matrix4f,
        normal: Matrix3f,
        b: Bounds,
        red: Int, green: Int, blue: Int, alpha: Int
    ) {
        val x0 = b.minX.toFloat(); val x1 = b.maxX.toFloat()
        val y0 = b.minY.toFloat(); val y1 = b.maxY.toFloat()
        val z0 = b.minZ.toFloat(); val z1 = b.maxZ.toFloat()
        val corners = arrayOf(
            floatArrayOf(x0, y0, z0), floatArrayOf(x1, y0, z0),
            floatArrayOf(x1, y0, z1), floatArrayOf(x0, y0, z1),
            floatArrayOf(x0, y1, z0), floatArrayOf(x1, y1, z0),
            floatArrayOf(x1, y1, z1), floatArrayOf(x0, y1, z1)
        )
        val edges = arrayOf(
            intArrayOf(0, 1), intArrayOf(1, 2), intArrayOf(2, 3), intArrayOf(3, 0),
            intArrayOf(4, 5), intArrayOf(5, 6), intArrayOf(6, 7), intArrayOf(7, 4),
            intArrayOf(0, 4), intArrayOf(1, 5), intArrayOf(2, 6), intArrayOf(3, 7)
        )
        for (edge in edges) {
            val a = corners[edge[0]]; val c = corners[edge[1]]
            consumer.vertex(matrix, a[0], a[1], a[2]).color(red, green, blue, alpha).normal(normal, 0f, 1f, 0f).endVertex()
            consumer.vertex(matrix, c[0], c[1], c[2]).color(red, green, blue, alpha).normal(normal, 0f, 1f, 0f).endVertex()
        }
    }

    private fun drawBarrier(consumer: VertexConsumer, matrix: Matrix4f, normal: Matrix3f, b: Bounds) {
        val x0 = b.minX.toFloat(); val x1 = b.maxX.toFloat()
        val y0 = b.minY.toFloat(); val y1 = b.maxY.toFloat()
        val z0 = b.minZ.toFloat(); val z1 = b.maxZ.toFloat()
        val uX = (x1 - x0) / 2f; val uY = (y1 - y0) / 2f; val uZ = (z1 - z0) / 2f
        val vX = uZ; val vY = uX; val vZ = uY

        // Six translucent, tiled faces. The texture is a red, barrier-inspired lattice.
        quad(consumer, matrix, normal, -1f, 0f, 0f,
            TexturedVertex(x0,y0,z0,0f,0f), TexturedVertex(x0,y0,z1,vX,0f),
            TexturedVertex(x0,y1,z1,vX,uY), TexturedVertex(x0,y1,z0,0f,uY))
        quad(consumer, matrix, normal, 1f, 0f, 0f,
            TexturedVertex(x1,y0,z1,0f,0f), TexturedVertex(x1,y0,z0,vX,0f),
            TexturedVertex(x1,y1,z0,vX,uY), TexturedVertex(x1,y1,z1,0f,uY))
        quad(consumer, matrix, normal, 0f, 0f, -1f,
            TexturedVertex(x1,y0,z0,0f,0f), TexturedVertex(x0,y0,z0,vY,0f),
            TexturedVertex(x0,y1,z0,vY,uZ), TexturedVertex(x1,y1,z0,0f,uZ))
        quad(consumer, matrix, normal, 0f, 0f, 1f,
            TexturedVertex(x0,y0,z1,0f,0f), TexturedVertex(x1,y0,z1,vY,0f),
            TexturedVertex(x1,y1,z1,vY,uZ), TexturedVertex(x0,y1,z1,0f,uZ))
        quad(consumer, matrix, normal, 0f, 1f, 0f,
            TexturedVertex(x0,y1,z0,0f,0f), TexturedVertex(x0,y1,z1,0f,vZ),
            TexturedVertex(x1,y1,z1,uX,vZ), TexturedVertex(x1,y1,z0,uX,0f))
        quad(consumer, matrix, normal, 0f, -1f, 0f,
            TexturedVertex(x0,y0,z1,0f,0f), TexturedVertex(x0,y0,z0,0f,vZ),
            TexturedVertex(x1,y0,z0,uX,vZ), TexturedVertex(x1,y0,z1,uX,0f))
    }

    private fun quad(
        consumer: VertexConsumer,
        matrix: Matrix4f,
        normalMatrix: Matrix3f,
        nx: Float, ny: Float, nz: Float,
        a: TexturedVertex, b: TexturedVertex, c: TexturedVertex, d: TexturedVertex
    ) {
        vertex(consumer, matrix, normalMatrix, a, nx, ny, nz)
        vertex(consumer, matrix, normalMatrix, b, nx, ny, nz)
        vertex(consumer, matrix, normalMatrix, c, nx, ny, nz)
        vertex(consumer, matrix, normalMatrix, d, nx, ny, nz)
    }

    private fun vertex(
        consumer: VertexConsumer,
        matrix: Matrix4f,
        normalMatrix: Matrix3f,
        vertex: TexturedVertex,
        nx: Float, ny: Float, nz: Float
    ) {
        consumer.vertex(matrix, vertex.x, vertex.y, vertex.z)
            .color(255, 255, 255, 145)
            .uv(vertex.u, vertex.v)
            .overlayCoords(OverlayTexture.NO_OVERLAY)
            .uv2(LightTexture.FULL_BRIGHT)
            .normal(normalMatrix, nx, ny, nz)
            .endVertex()
    }
}
