package tintiksavo.magic.mixin;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.context.BlockPlaceContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import tintiksavo.magic.security.MagicSecurityData;

@Mixin(BlockItem.class)
public abstract class MagicSecurityPlaceMixin {
    @Inject(method = "place", at = @At("HEAD"), cancellable = true)
    private void magic$denyProtectedPlace(BlockPlaceContext context, CallbackInfoReturnable<InteractionResult> cir) {
        if (context.getLevel() instanceof ServerLevel serverLevel &&
                !MagicSecurityData.canAct(serverLevel, context.getPlayer(), context.getClickedPos(), "place")) {
            cir.setReturnValue(InteractionResult.FAIL);
        }
    }
}
