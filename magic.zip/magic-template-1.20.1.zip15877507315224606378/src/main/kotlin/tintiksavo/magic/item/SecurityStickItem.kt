package tintiksavo.magic.item

import net.minecraft.network.chat.Component
import net.minecraft.server.level.ServerLevel
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.InteractionResult
import net.minecraft.world.item.Item
import net.minecraft.world.item.context.UseOnContext
import tintiksavo.magic.security.MagicSecurityData

/** Cycles a block-specific exception: inherit -> allow -> deny -> inherit. */
class SecurityStickItem : Item(Properties().stacksTo(1)) {
    override fun useOn(context: UseOnContext): InteractionResult {
        val player = context.player ?: return InteractionResult.PASS
        val level = context.level
        if (level !is ServerLevel) return InteractionResult.SUCCESS
        if (player !is ServerPlayer || !player.hasPermissions(2)) {
            player.displayClientMessage(Component.literal("Solo un administrador puede configurar Magic Security."), true)
            return InteractionResult.FAIL
        }

        val action = if (player.isCrouching) "place" else "break"
        val state = MagicSecurityData.get(level.server).cycleOverride(level, context.clickedPos, action)
        val label = when (state) {
            MagicSecurityData.ALLOW -> "PERMITIDO"
            MagicSecurityData.DENY -> "PROHIBIDO"
            else -> "HEREDADO"
        }
        player.displayClientMessage(
            Component.literal("Magic Security: ${if (action == "break") "romper" else "colocar"} = $label en ${context.clickedPos.x}, ${context.clickedPos.y}, ${context.clickedPos.z}"),
            true
        )
        return InteractionResult.SUCCESS
    }
}
