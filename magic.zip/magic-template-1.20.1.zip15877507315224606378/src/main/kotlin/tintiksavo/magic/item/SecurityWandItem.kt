package tintiksavo.magic.item

import net.minecraft.world.item.Item

/** Selection tool. Left-click a block for position 1 and right-click for position 2. */
class SecurityWandItem : Item(Properties().stacksTo(1))
