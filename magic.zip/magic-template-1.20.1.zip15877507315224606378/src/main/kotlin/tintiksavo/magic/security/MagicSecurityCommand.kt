package tintiksavo.magic.security

import com.mojang.brigadier.CommandDispatcher
import com.mojang.brigadier.arguments.StringArgumentType
import net.minecraft.commands.CommandSourceStack
import net.minecraft.commands.Commands
import net.minecraft.commands.SharedSuggestionProvider
import net.minecraft.network.chat.Component
import net.minecraft.server.level.ServerLevel
import tintiksavo.magic.item.ModItems

object MagicSecurityCommand {
    fun register(dispatcher: CommandDispatcher<CommandSourceStack>) {
        dispatcher.register(
            Commands.literal("magicsecurity")
                .requires { it.hasPermission(2) }
                .then(Commands.literal("wand").executes { context ->
                    val player = context.source.playerOrException
                    val stack = ModItems.SECURITY_WAND.defaultInstance
                    if (!player.inventory.add(stack)) player.drop(stack, false)
                    context.source.sendSuccess(
                        { Component.literal("Recibiste la Magic Security Wand: clic izquierdo = punto 1; clic derecho = punto 2.") },
                        false
                    )
                    1
                })
                .then(Commands.literal("stick").executes { context ->
                    val player = context.source.playerOrException
                    val stack = ModItems.SECURITY_STICK.defaultInstance
                    if (!player.inventory.add(stack)) player.drop(stack, false)
                    context.source.sendSuccess(
                        { Component.literal("Recibiste el Security Stick: clic derecho = excepción de romper; agachado + clic derecho = excepción de colocar.") },
                        false
                    )
                    1
                })
                .then(Commands.literal("pos1").executes { context ->
                    val player = context.source.playerOrException
                    val level = player.level() as ServerLevel
                    val data = MagicSecurityData.get(context.source.server)
                    data.setSelectionPoint(player.uuid, level, player.blockPosition(), first = true)
                    MagicSecurityNetworking.syncSelection(player)
                    context.source.sendSuccess(
                        { Component.literal("Magic Security: Punto 1 = ${player.blockX}, ${player.blockY}, ${player.blockZ}") }, false
                    )
                    1
                })
                .then(Commands.literal("pos2").executes { context ->
                    val player = context.source.playerOrException
                    val level = player.level() as ServerLevel
                    val data = MagicSecurityData.get(context.source.server)
                    if (!data.setSelectionPoint(player.uuid, level, player.blockPosition(), first = false)) {
                        context.source.sendFailure(Component.literal("Primero establece el punto 1 en esta misma dimensión."))
                        0
                    } else {
                        MagicSecurityNetworking.syncSelection(player)
                        context.source.sendSuccess(
                            { Component.literal("Magic Security: Punto 2 = ${player.blockX}, ${player.blockY}, ${player.blockZ}") }, false
                        )
                        1
                    }
                })
                .then(Commands.literal("selection").then(Commands.literal("clear").executes { context ->
                    val player = context.source.playerOrException
                    MagicSecurityData.get(context.source.server).clearSelection(player.uuid)
                    MagicSecurityNetworking.syncSelection(player)
                    context.source.sendSuccess({ Component.literal("Selección de Magic Security borrada.") }, false)
                    1
                }))
                .then(Commands.literal("global")
                    .then(Commands.literal("break").then(ruleArgument("rule", "global_break")))
                    .then(Commands.literal("place").then(ruleArgument("rule", "global_place")))
                )
                .then(Commands.literal("region")
                    .then(Commands.literal("create")
                        .then(Commands.argument("name", StringArgumentType.word()).executes { context ->
                            val player = context.source.playerOrException
                            val data = MagicSecurityData.get(context.source.server)
                            val selection = data.selection(player.uuid)
                            val first = selection.first
                            val second = selection.second
                            if (first == null || second == null) {
                                context.source.sendFailure(Component.literal("Selecciona dos puntos con la Magic Security Wand antes de crear la región."))
                                0
                            } else if (selection.dimension != (player.level() as ServerLevel).dimension().location().toString()) {
                                context.source.sendFailure(Component.literal("La selección pertenece a otra dimensión."))
                                0
                            } else {
                                val name = StringArgumentType.getString(context, "name")
                                if (!data.createRegion(name, player.level() as ServerLevel, first, second)) {
                                    context.source.sendFailure(Component.literal("Ya existe una región con ese nombre."))
                                    0
                                } else {
                                    data.clearSelection(player.uuid)
                                    MagicSecurityNetworking.syncSelection(player)
                                    MagicSecurityNetworking.syncAll(context.source.server)
                                    context.source.sendSuccess({ Component.literal("Región '$name' creada. Su contorno ya está visible para los administradores.") }, true)
                                    1
                                }
                            }
                        })
                    )
                    .then(Commands.literal("list").executes { context ->
                        val regions = MagicSecurityData.get(context.source.server).regions.values
                        val text = regions.joinToString(" | ") {
                            "${it.name} [${if (it.safetyEnabled) "SEGURIDAD ACTIVA" else "seguridad apagada"}]"
                        }.ifEmpty { "ninguna" }
                        context.source.sendSuccess({ Component.literal("Regiones Magic Security: $text") }, false)
                        1
                    })
                    .then(Commands.literal("delete")
                        .then(Commands.argument("name", StringArgumentType.word()).executes { context ->
                            val name = StringArgumentType.getString(context, "name")
                            if (MagicSecurityData.get(context.source.server).removeRegion(name)) {
                                MagicSecurityNetworking.syncAll(context.source.server)
                                context.source.sendSuccess({ Component.literal("Región eliminada: $name") }, true)
                                1
                            } else {
                                context.source.sendFailure(Component.literal("No existe la región '$name'."))
                                0
                            }
                        })
                    )
                    .then(Commands.literal("break")
                        .then(Commands.argument("name", StringArgumentType.word())
                            .then(ruleArgument("rule", "break"))
                        )
                    )
                    .then(Commands.literal("place")
                        .then(Commands.argument("name", StringArgumentType.word())
                            .then(ruleArgument("rule", "place"))
                        )
                    )
                    .then(Commands.literal("safety")
                        .then(Commands.argument("name", StringArgumentType.word())
                            .then(Commands.argument("state", StringArgumentType.word())
                                .suggests { _, builder -> SharedSuggestionProvider.suggest(listOf("on", "off"), builder) }
                                .executes { context ->
                                    val name = StringArgumentType.getString(context, "name")
                                    val state = StringArgumentType.getString(context, "state").lowercase()
                                    if (state != "on" && state != "off") {
                                        context.source.sendFailure(Component.literal("Usa 'on' o 'off'."))
                                        0
                                    } else {
                                        val enabled = state == "on"
                                        if (!MagicSecurityData.get(context.source.server).setRegionSafety(name, enabled)) {
                                            context.source.sendFailure(Component.literal("No existe la región '$name'."))
                                            0
                                        } else {
                                            if (!enabled) {
                                                MagicSecurityZoneManager.cancelRegion(context.source.server, name)
                                            }
                                            MagicSecurityNetworking.syncAll(context.source.server)
                                            context.source.sendSuccess(
                                                { Component.literal("Zona de seguridad '$name': ${if (enabled) "ACTIVADA" else "DESACTIVADA"}.") }, true
                                            )
                                            1
                                        }
                                    }
                                }
                            )
                        )
                    )
                )
        )
    }

    private fun ruleArgument(argumentName: String, action: String) =
        Commands.argument(argumentName, StringArgumentType.word())
            .suggests { _, builder -> SharedSuggestionProvider.suggest(listOf("allow", "deny", "inherit"), builder) }
            .executes { context ->
                val regionName = if (action.startsWith("global_")) null else StringArgumentType.getString(context, "name")
                val rule = StringArgumentType.getString(context, argumentName).lowercase()
                val value = when (rule) {
                    "allow" -> MagicSecurityData.ALLOW
                    "deny" -> MagicSecurityData.DENY
                    "inherit" -> MagicSecurityData.INHERIT
                    else -> {
                        context.source.sendFailure(Component.literal("Usa allow, deny o inherit."))
                        return@executes 0
                    }
                }
                val data = MagicSecurityData.get(context.source.server)
                val changed = when (action) {
                    "global_break" -> data.setGlobalRule("break", value)
                    "global_place" -> data.setGlobalRule("place", value)
                    else -> data.setRegionRule(regionName!!, action, value)
                }
                if (!changed) {
                    context.source.sendFailure(Component.literal("No existe la región '$regionName'."))
                    0
                } else {
                    MagicSecurityNetworking.syncAll(context.source.server)
                    val label = if (action.startsWith("global_")) "global ${action.removePrefix("global_")}" else "$action de '$regionName'"
                    context.source.sendSuccess({ Component.literal("Regla $label = $rule.") }, true)
                    1
                }
            }
}
