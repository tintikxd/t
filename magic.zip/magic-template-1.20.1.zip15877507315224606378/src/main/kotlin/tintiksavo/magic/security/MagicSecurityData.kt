package tintiksavo.magic.security

import net.minecraft.core.BlockPos
import net.minecraft.nbt.CompoundTag
import net.minecraft.nbt.ListTag
import net.minecraft.nbt.Tag
import net.minecraft.server.MinecraftServer
import net.minecraft.server.level.ServerLevel
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.entity.player.Player
import net.minecraft.world.level.saveddata.SavedData
import java.util.UUID

/** Persistent configuration for Magic Security. Temporary selections are kept only in memory. */
class MagicSecurityData : SavedData() {
    data class Region(
        val name: String,
        val dimension: String,
        val x1: Int,
        val y1: Int,
        val z1: Int,
        val x2: Int,
        val y2: Int,
        val z2: Int,
        var breakRule: Int = INHERIT,
        var placeRule: Int = INHERIT,
        var safetyEnabled: Boolean = false
    ) {
        val minX get() = minOf(x1, x2)
        val minY get() = minOf(y1, y2)
        val minZ get() = minOf(z1, z2)
        val maxX get() = maxOf(x1, x2)
        val maxY get() = maxOf(y1, y2)
        val maxZ get() = maxOf(z1, z2)

        fun contains(level: ServerLevel, pos: BlockPos): Boolean =
            dimension == level.dimension().location().toString() &&
                pos.x in minX..maxX && pos.y in minY..maxY && pos.z in minZ..maxZ
    }

    data class Selection(
        var dimension: String? = null,
        var first: BlockPos? = null,
        var second: BlockPos? = null
    )

    val regions: MutableMap<String, Region> = linkedMapOf()
    var globalBreakRule: Int = INHERIT
        private set
    var globalPlaceRule: Int = INHERIT
        private set
    private val overrides: MutableMap<String, Int> = linkedMapOf()
    private val selections: MutableMap<UUID, Selection> = linkedMapOf()

    fun selection(player: UUID): Selection = selections.getOrPut(player) { Selection() }

    fun setSelectionPoint(player: UUID, level: ServerLevel, pos: BlockPos, first: Boolean): Boolean {
        val selection = selection(player)
        val dimension = level.dimension().location().toString()
        if (first) {
            selection.dimension = dimension
            selection.first = pos.immutable()
            selection.second = null
            return true
        }
        if (selection.first == null || selection.dimension != dimension) return false
        selection.second = pos.immutable()
        return true
    }

    fun clearSelection(player: UUID) {
        selections.remove(player)
    }

    fun createRegion(name: String, level: ServerLevel, first: BlockPos, second: BlockPos): Boolean {
        val key = name.lowercase()
        if (key.isBlank() || key in regions) return false
        regions[key] = Region(
            name = key,
            dimension = level.dimension().location().toString(),
            x1 = first.x, y1 = first.y, z1 = first.z,
            x2 = second.x, y2 = second.y, z2 = second.z
        )
        setDirty()
        return true
    }

    fun removeRegion(name: String): Boolean {
        val removed = regions.remove(name.lowercase()) != null
        if (removed) setDirty()
        return removed
    }

    fun setGlobalRule(action: String, value: Int): Boolean {
        when (action) {
            "break" -> globalBreakRule = value
            "place" -> globalPlaceRule = value
            else -> return false
        }
        setDirty()
        return true
    }

    fun setRegionRule(name: String, action: String, value: Int): Boolean {
        val region = regions[name.lowercase()] ?: return false
        when (action) {
            "break" -> region.breakRule = value
            "place" -> region.placeRule = value
            else -> return false
        }
        setDirty()
        return true
    }

    fun setRegionSafety(name: String, enabled: Boolean): Boolean {
        val region = regions[name.lowercase()] ?: return false
        if (region.safetyEnabled == enabled) return true
        region.safetyEnabled = enabled
        setDirty()
        return true
    }

    fun cycleOverride(level: ServerLevel, pos: BlockPos, action: String): Int {
        val key = overrideKey(level, pos, action)
        val next = when (overrides[key] ?: INHERIT) {
            INHERIT -> ALLOW
            ALLOW -> DENY
            else -> INHERIT
        }
        if (next == INHERIT) overrides.remove(key) else overrides[key] = next
        setDirty()
        return next
    }

    fun effective(level: ServerLevel, pos: BlockPos, action: String): Boolean {
        val local = overrides[overrideKey(level, pos, action)]
        if (local != null) return local == ALLOW

        // The newest matching region with an explicit rule wins when regions overlap.
        for (region in regions.values.toList().asReversed()) {
            if (!region.contains(level, pos)) continue
            val rule = when (action) {
                "break" -> region.breakRule
                "place" -> region.placeRule
                else -> INHERIT
            }
            if (rule != INHERIT) return rule == ALLOW
        }
        val globalRule = when (action) {
            "break" -> globalBreakRule
            "place" -> globalPlaceRule
            else -> INHERIT
        }
        if (globalRule != INHERIT) return globalRule == ALLOW

        // No configured rule means vanilla Minecraft behavior.
        return true
    }

    fun activeSafetyRegion(level: ServerLevel, pos: BlockPos): Region? =
        regions.values.toList().asReversed().firstOrNull {
            it.safetyEnabled && it.contains(level, pos)
        }

    private fun overrideKey(level: ServerLevel, pos: BlockPos, action: String) =
        "${level.dimension().location()}|${pos.x}|${pos.y}|${pos.z}|$action"

    override fun save(tag: CompoundTag): CompoundTag {
        val regionList = ListTag()
        regions.values.forEach { region ->
            val item = CompoundTag()
            item.putString("name", region.name)
            item.putString("dimension", region.dimension)
            item.putInt("x1", region.x1); item.putInt("y1", region.y1); item.putInt("z1", region.z1)
            item.putInt("x2", region.x2); item.putInt("y2", region.y2); item.putInt("z2", region.z2)
            item.putInt("breakRule", region.breakRule)
            item.putInt("placeRule", region.placeRule)
            item.putBoolean("safetyEnabled", region.safetyEnabled)
            regionList.add(item)
        }
        tag.put("regions", regionList)
        tag.putInt("globalBreakRule", globalBreakRule)
        tag.putInt("globalPlaceRule", globalPlaceRule)

        val overrideList = ListTag()
        overrides.forEach { (key, value) ->
            val item = CompoundTag()
            item.putString("key", key)
            item.putInt("value", value)
            overrideList.add(item)
        }
        tag.put("overrides", overrideList)
        return tag
    }

    companion object {
        const val INHERIT = -1
        const val DENY = 0
        const val ALLOW = 1
        private const val DATA_NAME = "magic_security"

        fun get(server: MinecraftServer): MagicSecurityData {
            return server.overworld().dataStorage.computeIfAbsent(
                { tag: CompoundTag -> load(tag) },
                { MagicSecurityData() },
                DATA_NAME
            )
        }

        private fun load(tag: CompoundTag): MagicSecurityData {
            val data = MagicSecurityData()
            data.globalBreakRule = if (tag.contains("globalBreakRule")) tag.getInt("globalBreakRule") else INHERIT
            data.globalPlaceRule = if (tag.contains("globalPlaceRule")) tag.getInt("globalPlaceRule") else INHERIT
            val regionList = tag.getList("regions", Tag.TAG_COMPOUND.toInt())
            for (index in 0 until regionList.size) {
                val item = regionList.getCompound(index)
                val region = Region(
                    name = item.getString("name"),
                    dimension = item.getString("dimension"),
                    x1 = item.getInt("x1"), y1 = item.getInt("y1"), z1 = item.getInt("z1"),
                    x2 = item.getInt("x2"), y2 = item.getInt("y2"), z2 = item.getInt("z2"),
                    breakRule = if (item.contains("breakRule")) item.getInt("breakRule") else INHERIT,
                    placeRule = if (item.contains("placeRule")) item.getInt("placeRule") else INHERIT,
                    safetyEnabled = item.getBoolean("safetyEnabled")
                )
                data.regions[region.name] = region
            }

            val overrideList = tag.getList("overrides", Tag.TAG_COMPOUND.toInt())
            for (index in 0 until overrideList.size) {
                val item = overrideList.getCompound(index)
                data.overrides[item.getString("key")] = item.getInt("value")
            }
            return data
        }

        @JvmStatic
        fun canAct(level: ServerLevel, player: Player?, pos: BlockPos, action: String): Boolean {
            // Only actual server operators bypass configured rules. Null-player placements
            // (for example, automated placement paths) still obey protection rules.
            if (player is ServerPlayer && player.hasPermissions(2)) return true
            return get(level.server).effective(level, pos, action)
        }
    }
}
