package tintiksavo.magic.security

import net.fabricmc.fabric.api.event.player.AttackBlockCallback
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents
import net.fabricmc.fabric.api.event.player.UseBlockCallback
import net.minecraft.network.chat.Component
import net.minecraft.server.level.ServerLevel
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.InteractionResult
import tintiksavo.magic.item.ModItems

object MagicSecurityEvents {
    fun register() {
        PlayerBlockBreakEvents.BEFORE.register { world, player, pos, _, _ ->
            if (world is ServerLevel) MagicSecurityData.canAct(world, player, pos, "break") else true
        }

        // Left click with the wand = position 1.
        AttackBlockCallback.EVENT.register { player, world, hand, pos, _ ->
            if (!player.getItemInHand(hand).`is`(ModItems.SECURITY_WAND)) {
                InteractionResult.PASS
            } else if (world.isClientSide) {
                if (player.isSpectator) InteractionResult.FAIL else InteractionResult.SUCCESS
            } else if (player !is ServerPlayer || !player.hasPermissions(2)) {
                player.displayClientMessage(Component.literal("Solo un administrador puede usar la Magic Security Wand."), true)
                InteractionResult.FAIL
            } else {
                val level = world as ServerLevel
                MagicSecurityData.get(level.server).setSelectionPoint(player.uuid, level, pos, first = true)
                MagicSecurityNetworking.syncSelection(player)
                player.displayClientMessage(
                    Component.literal("Magic Security · Punto 1: ${pos.x}, ${pos.y}, ${pos.z}"), true
                )
                InteractionResult.SUCCESS
            }
        }

        // Right click with the wand = position 2.
        UseBlockCallback.EVENT.register { player, world, hand, hit ->
            if (!player.getItemInHand(hand).`is`(ModItems.SECURITY_WAND)) {
                InteractionResult.PASS
            } else if (world.isClientSide) {
                if (player.isSpectator) InteractionResult.FAIL else InteractionResult.SUCCESS
            } else if (player !is ServerPlayer || !player.hasPermissions(2)) {
                player.displayClientMessage(Component.literal("Solo un administrador puede usar la Magic Security Wand."), true)
                InteractionResult.FAIL
            } else {
                val level = world as ServerLevel
                val data = MagicSecurityData.get(level.server)
                if (!data.setSelectionPoint(player.uuid, level, hit.blockPos, first = false)) {
                    player.displayClientMessage(
                        Component.literal("Primero marca el punto 1 en esta dimensión con clic izquierdo."), true
                    )
                } else {
                    MagicSecurityNetworking.syncSelection(player)
                    player.displayClientMessage(
                        Component.literal("Magic Security · Punto 2: ${hit.blockPos.x}, ${hit.blockPos.y}, ${hit.blockPos.z}"), true
                    )
                }
                InteractionResult.SUCCESS
            }
        }
    }
}
