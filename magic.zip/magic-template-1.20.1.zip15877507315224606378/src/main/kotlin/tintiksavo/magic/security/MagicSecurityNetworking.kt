package tintiksavo.magic.security

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking
import net.minecraft.core.BlockPos
import net.minecraft.network.FriendlyByteBuf
import net.minecraft.resources.ResourceLocation
import net.minecraft.server.MinecraftServer
import net.minecraft.server.level.ServerPlayer
import java.util.UUID
import tintiksavo.magic.Magic

/** Sends only the data each client is allowed to see. */
object MagicSecurityNetworking {
    val REGIONS_CHANNEL: ResourceLocation = Magic.id("security_regions")
    val SELECTION_CHANNEL: ResourceLocation = Magic.id("security_selection")
    private val permissionCache = mutableMapOf<UUID, Boolean>()
    private var permissionRefreshTicks = 0

    fun register() {
        ServerPlayConnectionEvents.JOIN.register { handler, _, _ ->
            syncRegions(handler.player)
            syncSelection(handler.player)
        }
        ServerPlayConnectionEvents.DISCONNECT.register { handler, _ ->
            permissionCache.remove(handler.player.uuid)
        }
        ServerTickEvents.END_SERVER_TICK.register { server ->
            permissionRefreshTicks++
            if (permissionRefreshTicks >= 40) {
                permissionRefreshTicks = 0
                for (player in server.playerList.players) {
                    val currentPermission = player.hasPermissions(2)
                    val previousPermission = permissionCache[player.uuid]
                    if (previousPermission != null && previousPermission != currentPermission) {
                        syncRegions(player)
                        syncSelection(player)
                    }
                }
            }
        }
    }

    fun syncAll(server: MinecraftServer) {
        server.playerList.players.forEach(::syncRegions)
    }

    fun syncRegions(player: ServerPlayer) {
        val data = MagicSecurityData.get(player.server)
        val isAdmin = player.hasPermissions(2)
        permissionCache[player.uuid] = isAdmin
        val buffer = PacketByteBufs.create()
        buffer.writeBoolean(isAdmin)

        val adminRegions = if (isAdmin) data.regions.values.toList() else emptyList()
        buffer.writeVarInt(adminRegions.size)
        adminRegions.forEach { writeRegion(buffer, it) }

        // Active danger-zone boundaries are public because everyone inside/near them must see the barrier.
        val safetyZones = data.regions.values.filter { it.safetyEnabled }
        buffer.writeVarInt(safetyZones.size)
        safetyZones.forEach { writeRegion(buffer, it) }

        ServerPlayNetworking.send(player, REGIONS_CHANNEL, buffer)
    }

    fun syncSelection(player: ServerPlayer) {
        val selection = MagicSecurityData.get(player.server).selection(player.uuid)
        val buffer = PacketByteBufs.create()
        buffer.writeBoolean(player.hasPermissions(2))
        buffer.writeUtf(selection.dimension ?: "")
        writeOptionalPos(buffer, selection.first)
        writeOptionalPos(buffer, selection.second)
        ServerPlayNetworking.send(player, SELECTION_CHANNEL, buffer)
    }

    private fun writeRegion(buffer: FriendlyByteBuf, region: MagicSecurityData.Region) {
        buffer.writeUtf(region.name)
        buffer.writeUtf(region.dimension)
        buffer.writeInt(region.minX); buffer.writeInt(region.minY); buffer.writeInt(region.minZ)
        buffer.writeInt(region.maxX); buffer.writeInt(region.maxY); buffer.writeInt(region.maxZ)
        buffer.writeBoolean(region.safetyEnabled)
    }

    private fun writeOptionalPos(buffer: FriendlyByteBuf, pos: BlockPos?) {
        buffer.writeBoolean(pos != null)
        if (pos != null) {
            buffer.writeBlockPos(pos)
        }
    }
}
