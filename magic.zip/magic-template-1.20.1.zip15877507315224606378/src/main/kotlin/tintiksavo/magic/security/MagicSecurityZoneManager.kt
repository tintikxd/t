package tintiksavo.magic.security

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents
import net.minecraft.ChatFormatting
import net.minecraft.network.chat.Component
import net.minecraft.network.protocol.game.ClientboundClearTitlesPacket
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket
import net.minecraft.world.effect.MobEffects
import net.minecraft.server.level.ServerLevel
import net.minecraft.server.MinecraftServer
import net.minecraft.server.level.ServerPlayer
import java.util.UUID

/** Server-authoritative warning and escalating instant-damage sequence. */
object MagicSecurityZoneManager {
    private const val WARNING_TICKS = 5 * 20
    private const val DAMAGE_INTERVAL_TICKS = 20
    private const val MAX_DAMAGE_AMPLIFIER = 10

    private data class Exposure(
        var regionName: String,
        var warningTicks: Int = WARNING_TICKS,
        var damageTicks: Int = 0,
        var amplifier: Int = 0
    )

    private val exposures = mutableMapOf<UUID, Exposure>()

    fun register() {
        ServerTickEvents.END_SERVER_TICK.register(::tick)
    }

    /** Cancels an exposure immediately when an administrator disables its zone. */
    fun cancelRegion(server: MinecraftServer, regionName: String) {
        val affected = exposures.filterValues { it.regionName.equals(regionName, ignoreCase = true) }.keys.toList()
        for (uuid in affected) {
            exposures.remove(uuid)
            server.playerList.getPlayer(uuid)?.let(::clearWarning)
        }
    }

    private fun tick(server: MinecraftServer) {
        val onlineIds = server.playerList.players.mapTo(hashSetOf()) { it.uuid }
        exposures.keys.removeIf { it !in onlineIds }

        for (player in server.playerList.players) {
            val previous = exposures[player.uuid]
            val current = if (player.isAlive && !player.isCreative && !player.isSpectator && !player.hasPermissions(2)) {
                MagicSecurityData.get(server).activeSafetyRegion(player.level() as ServerLevel, player.blockPosition())
            } else null

            if (current == null) {
                if (previous != null) {
                    exposures.remove(player.uuid)
                    clearWarning(player)
                }
                continue
            }

            if (previous == null) {
                exposures[player.uuid] = Exposure(current.name)
                showWarning(player)
                continue
            }

            // Keep the exposure associated with the currently winning zone when zones overlap.
            previous.regionName = current.name

            if (previous.warningTicks > 0) {
                previous.warningTicks--
                if (previous.warningTicks == 0) {
                    applyEscalatingDamage(player, previous)
                    previous.damageTicks = DAMAGE_INTERVAL_TICKS
                }
            } else {
                previous.damageTicks--
                if (previous.damageTicks <= 0) {
                    applyEscalatingDamage(player, previous)
                    previous.damageTicks = DAMAGE_INTERVAL_TICKS
                }
            }
        }
    }

    private fun showWarning(player: ServerPlayer) {
        player.connection.send(ClientboundSetTitlesAnimationPacket(5, 90, 5))
        player.connection.send(
            ClientboundSetTitleTextPacket(
                Component.literal("SAL DE ESTA ZONA").withStyle(ChatFormatting.RED, ChatFormatting.BOLD)
            )
        )
        player.connection.send(
            ClientboundSetSubtitleTextPacket(
                Component.literal("Tienes 5 segundos para salir.").withStyle(ChatFormatting.RED)
            )
        )
    }

    private fun clearWarning(player: ServerPlayer) {
        player.connection.send(ClientboundClearTitlesPacket(false))
    }

    private fun applyEscalatingDamage(player: ServerPlayer, exposure: Exposure) {
        // MobEffects.HARM is the same instant-damage effect used by /effect, called directly.
        MobEffects.HARM.applyInstantenousEffect(
            null,
            null,
            player,
            exposure.amplifier.coerceAtMost(MAX_DAMAGE_AMPLIFIER),
            1.0
        )
        exposure.amplifier = (exposure.amplifier + 1).coerceAtMost(MAX_DAMAGE_AMPLIFIER)
    }
}
