package tintiksavo.magic.worldgen

import net.minecraft.world.level.levelgen.SurfaceRules
import terrablender.api.Regions
import terrablender.api.SurfaceRuleManager
import terrablender.api.TerraBlenderApi
import tintiksavo.magic.Magic
import tintiksavo.magic.block.ModBlocks

class MagicTerraBlender : TerraBlenderApi {

    override fun onTerraBlenderInitialized() {
        // Registrar el bioma del bosque mágico.
        Regions.register(MagicOverworldRegion())

        // Aplicar las reglas únicamente al bosque mágico.
        val magicSurfaceRule = SurfaceRules.ifTrue(
            SurfaceRules.isBiome(MagicBiomes.BOSQUE_MAGICO),
            SurfaceRules.sequence(
                // Capa superior.
                SurfaceRules.ifTrue(
                    SurfaceRules.ON_FLOOR,
                    SurfaceRules.state(
                        ModBlocks.MAGIC_GRASS.defaultBlockState()
                    )
                ),

                // Capa inmediatamente debajo de la superficie.
                SurfaceRules.ifTrue(
                    SurfaceRules.UNDER_FLOOR,
                    SurfaceRules.state(
                        ModBlocks.MAGIC_DIRT.defaultBlockState()
                    )
                )
            )
        )

        SurfaceRuleManager.addSurfaceRules(
            SurfaceRuleManager.RuleCategory.OVERWORLD,
            Magic.MOD_ID,
            magicSurfaceRule
        )
    }
}