package tintiksavo.magic.worldgen

import com.mojang.serialization.Codec
import net.minecraft.core.BlockPos
import net.minecraft.core.Direction
import net.minecraft.world.level.LevelSimulatedReader
import net.minecraft.world.level.block.Blocks
import net.minecraft.world.level.block.LeavesBlock
import net.minecraft.world.level.block.state.BlockState
import net.minecraft.world.level.levelgen.feature.Feature
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration
import net.minecraft.world.level.block.state.properties.BlockStateProperties
import net.minecraft.world.level.LevelReader
import net.minecraft.world.level.WorldGenLevel
import net.minecraft.util.RandomSource
import tintiksavo.magic.block.ModBlocks
import kotlin.math.abs

class WeirdTreeFeature :
    Feature<NoneFeatureConfiguration>(NoneFeatureConfiguration.CODEC) {

    override fun place(
        context: FeaturePlaceContext<NoneFeatureConfiguration>
    ): Boolean {
        val level = context.level()
        val origin = context.origin()
        val random = context.random()

        /*
         * IMPORTANTE:
         * Ya no exigimos que el bloque inferior sea MAGIC_DIRT.
         *
         * El placed feature limita la generación al bioma que
         * incluye magic:weird_tree_placed en su configuración.
         *
         * Aquí solo comprobamos que exista una superficie sólida
         * sobre la que pueda crecer el árbol.
         */
        val groundPos = origin.below()
        val groundState = level.getBlockState(groundPos)

        if (!groundState.isFaceSturdy(level, groundPos, Direction.UP)) {
            return false
        }

        // Altura principal del árbol.
        val height = 9 + random.nextInt(5)

        // Comprobar el espacio del tronco antes de generar.
        for (y in 0 until height) {
            val pos = origin.above(y)

            if (!isReplaceable(level, pos)) {
                return false
            }
        }

        // Generar el tronco principal.
        for (y in 0 until height) {
            val pos = origin.above(y)
            level.setBlock(pos, ModBlocks.MAGIC_LOG.defaultBlockState(), 3)
        }

        // Raíces que se extienden por el suelo.
        generateRoots(level, origin, random)

        // Ramas principales de diferentes longitudes.
        generateBranches(level, origin, height, random)

        // Copa tridimensional.
        val crownCenter = origin.above(height - 1)
        val crownRadius = 3 + random.nextInt(2)

        generateLeafCluster(
            level = level,
            center = crownCenter,
            radius = crownRadius
        )

        // Hojas adicionales alrededor de las ramas.
        for (i in 0 until 5) {
            val branchHeight = height - 2 - random.nextInt(4)
            val direction = Direction.Plane.HORIZONTAL
                .getRandomDirection(random)

            val branchLength = 2 + random.nextInt(3)

            var branchPos = origin.above(branchHeight)

            repeat(branchLength) {
                branchPos = branchPos.relative(direction)

                generateLeafCluster(
                    level = level,
                    center = branchPos.above(random.nextInt(2)),
                    radius = 2
                )
            }
        }

        return true
    }

    /**
     * Genera raíces que se extienden desde la base del tronco.
     */
    private fun generateRoots(
        level: WorldGenLevel,
        origin: BlockPos,
        random: RandomSource
    ) {
        for (direction in Direction.Plane.HORIZONTAL) {
            val length = 2 + random.nextInt(3)
            var rootPos = origin.below()

            for (i in 1..length) {
                rootPos = rootPos.relative(direction)

                // Las raíces siguen aproximadamente el terreno.
                if (random.nextInt(3) == 0) {
                    rootPos = rootPos.below()
                }

                if (rootPos.y <= level.minBuildHeight) {
                    break
                }

                val currentState = level.getBlockState(rootPos)

                if (!isReplaceable(level, rootPos) &&
                    !currentState.isAir
                ) {
                    break
                }

                level.setBlock(
                    rootPos,
                    ModBlocks.MAGIC_LOG.defaultBlockState(),
                    3
                )

                // Algunas raíces tienen una ramificación corta.
                if (i >= 2 && random.nextInt(3) == 0) {
                    val side = if (random.nextBoolean()) {
                        direction.clockWise
                    } else {
                        direction.counterClockWise
                    }

                    val sidePos = rootPos.relative(side)

                    if (isReplaceable(level, sidePos)) {
                        level.setBlock(
                            sidePos,
                            ModBlocks.MAGIC_LOG.defaultBlockState(),
                            3
                        )
                    }
                }
            }
        }
    }

    /**
     * Genera ramas principales y ramificaciones secundarias.
     */
    private fun generateBranches(
        level: WorldGenLevel,
        origin: BlockPos,
        height: Int,
        random: RandomSource
    ) {
        val branchLevels = listOf(
            height / 3,
            height / 2,
            height * 2 / 3,
            height - 2
        )

        for (branchHeight in branchLevels) {
            for (direction in Direction.Plane.HORIZONTAL) {
                // Algunas ramas se omiten para evitar simetría perfecta.
                if (random.nextInt(4) == 0) {
                    continue
                }

                val length = when (random.nextInt(3)) {
                    0 -> 2
                    1 -> 3
                    else -> 4
                }

                var branchPos = origin.above(branchHeight)

                for (i in 1..length) {
                    branchPos = branchPos.relative(direction)

                    // Las ramas ascienden ligeramente hacia sus extremos.
                    if (i > 1 && random.nextBoolean()) {
                        branchPos = branchPos.above()
                    }

                    if (isReplaceable(level, branchPos)) {
                        level.setBlock(
                            branchPos,
                            ModBlocks.MAGIC_LOG.defaultBlockState(),
                            3
                        )
                    }

                    // Ramificaciones secundarias.
                    if (i >= 2 && random.nextInt(3) == 0) {
                        val side = if (random.nextBoolean()) {
                            direction.clockWise
                        } else {
                            direction.counterClockWise
                        }

                        val secondaryPos = branchPos
                            .relative(side)
                            .above()

                        if (isReplaceable(level, secondaryPos)) {
                            level.setBlock(
                                secondaryPos,
                                ModBlocks.MAGIC_LOG.defaultBlockState(),
                                3
                            )
                        }

                        // Hojas en el extremo de la rama secundaria.
                        generateLeafCluster(
                            level = level,
                            center = secondaryPos.above(),
                            radius = 2
                        )
                    }
                }

                // Hojas en el extremo de la rama principal.
                generateLeafCluster(
                    level = level,
                    center = branchPos.above(),
                    radius = 2
                )
            }
        }
    }

    /**
     * Genera una copa tridimensional de hojas.
     *
     * Se usa una distribución aproximadamente esférica,
     * con pequeñas irregularidades para evitar una esfera perfecta.
     */
    private fun generateLeafCluster(
        level: WorldGenLevel,
        center: BlockPos,
        radius: Int
    ) {
        val leaves = persistentLeaves()

        for (x in -radius..radius) {
            for (y in -radius..radius) {
                for (z in -radius..radius) {
                    val distance = x * x + y * y + z * z

                    // Distribución volumétrica.
                    if (distance > radius * radius + 1) {
                        continue
                    }

                    val pos = center.offset(x, y, z)

                    if (isReplaceable(level, pos)) {
                        level.setBlock(pos, leaves, 3)
                    }
                }
            }
        }
    }

    /**
     * Determina qué bloques pueden sustituirse al generar el árbol.
     *
     * No se exige MAGIC_DIRT como sustrato.
     */
    private fun isReplaceable(
        level: LevelReader,
        pos: BlockPos
    ): Boolean {
        val state = level.getBlockState(pos)

        return state.isAir ||
                state.`is`(Blocks.GRASS) ||
                state.`is`(Blocks.TALL_GRASS) ||
                state.`is`(Blocks.FERN) ||
                state.`is`(Blocks.LARGE_FERN) ||
                state.`is`(Blocks.VINE) ||
                state.`is`(ModBlocks.MAGIC_GRASS) ||
                state.`is`(ModBlocks.MAGIC_LEAVES)
    }

    /**
     * Crea hojas persistentes para que no desaparezcan
     * por las mecánicas normales de degradación.
     */
    private fun persistentLeaves(): BlockState {
        var state = ModBlocks.MAGIC_LEAVES.defaultBlockState()

        if (state.hasProperty(BlockStateProperties.PERSISTENT)) {
            state = state.setValue(
                BlockStateProperties.PERSISTENT,
                true
            )
        }

        return state
    }
}